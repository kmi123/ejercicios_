let lista = [1, 4, 6, 10, 22, 55, 46, 2, 5, 0]
for (var numero = 0; numero < lista.length; numero++) {    
    if(lista[numero] > 3){
      console.log(lista[numero])
    }
  }



  