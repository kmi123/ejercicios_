let numero = prompt ("digite un numero")
if (numero % 1000 === 0 ) {
    alert("Haz ganado un premio ")
}
else {
    alert("Intentalo de nuevo")
}