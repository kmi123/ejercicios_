let numero = prompt ("digite un numero")
if (numero % 2 === 0 ) {
    document.write("es multiplo de dos")
}
else {
    document.write("no es multiplo de dos")
}