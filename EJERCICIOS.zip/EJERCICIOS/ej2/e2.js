let numero = prompt ("digite un numero")
if (numero % 2 === 0 ) {
    alert("Es par")
}
else {
    alert("No es par")
}